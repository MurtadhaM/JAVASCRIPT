import React from 'react'
function App() {
  return (
    <div className='container'>
      <h2>Advanced Tutorial</h2>
    </div>
  )
}

export default App
