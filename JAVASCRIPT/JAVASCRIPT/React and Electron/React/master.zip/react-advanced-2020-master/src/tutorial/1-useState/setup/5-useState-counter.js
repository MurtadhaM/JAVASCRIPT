import React, { useState } from 'react';

const UseStateCounter = () => {
  return <h2>useState counter example</h2>;
};

export default UseStateCounter;
